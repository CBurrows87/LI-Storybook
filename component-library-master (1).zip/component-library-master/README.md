# Component Library

A library of components, built using Storybook.

# Quick Guide

This is a very brief startup guide which is subject to change. 

To run Listers Component Library :-

CD into "listers-component-library"

Run: 'npm run storybook'

This will launch the site on: 
http://localhost:9009/  

That should be it. 
