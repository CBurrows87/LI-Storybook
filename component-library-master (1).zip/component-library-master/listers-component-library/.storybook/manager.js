import { addons } from "@storybook/addons";
import logoUrl from "../public/logo.svg";

addons.setConfig({
  theme: {

    
    base: "light",
    brandTitle: "Listers Component Library",
    brandUrl: "https://listers.co.uk",
    brandImage: process.env.NODE_ENV === "production" ? logoUrl : "/logo.svg"
  }
});
