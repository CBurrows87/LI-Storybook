import React from "react";
import "../../../scss/style.scss";
import PropTypes from "prop-types";
import cx from "classnames";

interface IProps {
  text?: string;
  varient?: string;
  buttonSize?: string;
  className?: string;

}

const Button = ({ text,varient, className, buttonSize }: IProps) => {
  const baseClass = "c-btn";
  const rootClass = cx(baseClass, className, {
    [`${baseClass}--${varient}`]: varient,
    [`${baseClass}--${buttonSize}`]: buttonSize
  });

  return <button className={rootClass}>{text}</button>;
};

Button.defaultProps = {
  text: "Button",
  varient: "primary",
  buttonSize: "large"
};

Button.propTypes = {
  text: PropTypes.string,
  varient: PropTypes.string,
  buttonSize: PropTypes.string

};

export default Button;
