import React, { Fragment } from "react";
import Button from "./Button";
import {withKnobs, select, text} from "@storybook/addon-knobs";

const varientOptions = {
  Primary: "primary",
  Secondary: "secondary",
  Tertiary: "tertiary",
  Positivte: "positive",
  Negative: "negative",
  Info: "info",
  Warning: "warning",
  Light: "light"
};

const buttonSizes = {
  Tiny: "tiny",
  Small: "small",
  Compact: "compact",
  Large: "large",
  Huge: "huge",
  Wide: "wide"
}

export const AllVarients = () => (
  <Fragment>
    <Button varient={varientOptions.Primary} text="Primary" />
    <Button varient={varientOptions.Secondary} />
    <Button varient={varientOptions.Tertiary} />
    <Button varient={varientOptions.Positivte} />
    <Button varient={varientOptions.Negative} />
    <Button varient={varientOptions.Info} />
    <Button varient={varientOptions.Warning} />
    <Button varient={varientOptions.Light} />
  </Fragment>
);

export const Playground = () => (
  <Button 
  text={text('Button Text', 'Button')}
  varient={select("Varient", varientOptions, "primary")} 
  buttonSize={select("Button Size", buttonSizes, "tiny")}

  />
);

export default {
  title: "Button",
  component: Button,
  decorators: [withKnobs]
};
